CREATE DATABASE  IF NOT EXISTS `covid` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `covid`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: covid
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `clinicinfo`
--

DROP TABLE IF EXISTS `clinicinfo`;
/*!50001 DROP VIEW IF EXISTS `clinicinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `clinicinfo` AS SELECT 
 1 AS `address`,
 1 AS `clinicName`,
 1 AS `cityName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `nonvaccinatedperson`
--

DROP TABLE IF EXISTS `nonvaccinatedperson`;
/*!50001 DROP VIEW IF EXISTS `nonvaccinatedperson`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `nonvaccinatedperson` AS SELECT 
 1 AS `healthCardId`,
 1 AS `personName`,
 1 AS `birthDate`,
 1 AS `gender`,
 1 AS `vaccineComplications`,
 1 AS `vaccinedStatus`,
 1 AS `UNLOCode`,
 1 AS `doseNumber`,
 1 AS `immunity`,
 1 AS `administedVaccineType`,
 1 AS `latestVaccinatedDate`,
 1 AS `address`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `lockdownhotspot`
--

DROP TABLE IF EXISTS `lockdownhotspot`;
/*!50001 DROP VIEW IF EXISTS `lockdownhotspot`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `lockdownhotspot` AS SELECT 
 1 AS `outbreakDistrict`,
 1 AS `numPeople`,
 1 AS `numCases`,
 1 AS `numResolved`,
 1 AS `numRecovered`,
 1 AS `UNLOCode`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `hospitalinfo`
--

DROP TABLE IF EXISTS `hospitalinfo`;
/*!50001 DROP VIEW IF EXISTS `hospitalinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `hospitalinfo` AS SELECT 
 1 AS `address`,
 1 AS `hospitalName`,
 1 AS `bedsAvailable`,
 1 AS `numOfCovidCases`,
 1 AS `cityName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `hccinfo`
--

DROP TABLE IF EXISTS `hccinfo`;
/*!50001 DROP VIEW IF EXISTS `hccinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `hccinfo` AS SELECT 
 1 AS `address`,
 1 AS `cityName`,
 1 AS `spotName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `healthcc`
--

DROP TABLE IF EXISTS `healthcc`;
/*!50001 DROP VIEW IF EXISTS `healthcc`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `healthcc` AS SELECT 
 1 AS `address`,
 1 AS `cityName`,
 1 AS `HealthName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `complicatedvaccines`
--

DROP TABLE IF EXISTS `complicatedvaccines`;
/*!50001 DROP VIEW IF EXISTS `complicatedvaccines`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `complicatedvaccines` AS SELECT 
 1 AS `UNLOCODE`,
 1 AS `latestVaccinatedDate`,
 1 AS `administedVaccineType`,
 1 AS `vaccineComplications`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `clinicinfo`
--

/*!50001 DROP VIEW IF EXISTS `clinicinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `clinicinfo` (`address`,`clinicName`,`cityName`) AS select `v`.`address` AS `address`,`v`.`clinicName` AS `clinicName`,`c`.`cityName` AS `cityName` from ((`vaccineclinic` `v` join `healthcarecentre` `hcc` on((`v`.`address` = `hcc`.`address`))) join `city` `c` on((`hcc`.`UNLOCode` = `c`.`UNLOCode`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `nonvaccinatedperson`
--

/*!50001 DROP VIEW IF EXISTS `nonvaccinatedperson`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `nonvaccinatedperson` AS select `person`.`healthCardId` AS `healthCardId`,`person`.`personName` AS `personName`,`person`.`birthDate` AS `birthDate`,`person`.`gender` AS `gender`,`person`.`vaccineComplications` AS `vaccineComplications`,`person`.`vaccinedStatus` AS `vaccinedStatus`,`person`.`UNLOCode` AS `UNLOCode`,`person`.`doseNumber` AS `doseNumber`,`person`.`immunity` AS `immunity`,`person`.`administedVaccineType` AS `administedVaccineType`,`person`.`latestVaccinatedDate` AS `latestVaccinatedDate`,`person`.`address` AS `address` from `person` where (`person`.`vaccinedStatus` = 'Not Vaccinated') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `lockdownhotspot`
--

/*!50001 DROP VIEW IF EXISTS `lockdownhotspot`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `lockdownhotspot` AS select `hotspot`.`outbreakDistrict` AS `outbreakDistrict`,`hotspot`.`numPeople` AS `numPeople`,`hotspot`.`numCases` AS `numCases`,`hotspot`.`numResolved` AS `numResolved`,`hotspot`.`numRecovered` AS `numRecovered`,`hotspot`.`UNLOCode` AS `UNLOCode` from `hotspot` where (`hotspot`.`numCases` > 100) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hospitalinfo`
--

/*!50001 DROP VIEW IF EXISTS `hospitalinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hospitalinfo` (`address`,`hospitalName`,`bedsAvailable`,`numOfCovidCases`,`cityName`) AS select `h`.`address` AS `address`,`h`.`hospitalName` AS `hospitalName`,`h`.`bedsAvailable` AS `bedsAvailable`,`h`.`numOfCovidCases` AS `numOfCovidCases`,`c`.`cityName` AS `cityName` from ((`hospital` `h` join `healthcarecentre` `hcc` on((`h`.`address` = `hcc`.`address`))) join `city` `c` on((`hcc`.`UNLOCode` = `c`.`UNLOCode`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hccinfo`
--

/*!50001 DROP VIEW IF EXISTS `hccinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hccinfo` (`address`,`cityName`,`spotName`) AS select `hcc`.`address` AS `address`,`c`.`cityName` AS `cityName`,`v`.`spotName` AS `spotName` from ((`healthcarecentre` `hcc` join `city` `c` on((`hcc`.`UNLOCode` = `c`.`UNLOCode`))) left join (select `vaccineclinic`.`clinicName` AS `spotName`,`vaccineclinic`.`address` AS `address` from `vaccineclinic` union select `hospital`.`hospitalName` AS `hospitalName`,`hospital`.`address` AS `address` from `hospital`) `v` on((`v`.`address` = `hcc`.`address`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `healthcc`
--

/*!50001 DROP VIEW IF EXISTS `healthcc`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `healthcc` (`address`,`cityName`,`HealthName`) AS select `hcc`.`address` AS `address`,`c`.`cityName` AS `cityName`,`h`.`hospitalName` AS `Hname` from (((`healthcarecentre` `hcc` join `city` `c` on((`c`.`UNLOCode` = `hcc`.`UNLOCode`))) left join `hospital` `h` on((`h`.`address` = `hcc`.`address`))) left join `vaccineclinic` `v` on((`v`.`address` = `hcc`.`address`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `complicatedvaccines`
--

/*!50001 DROP VIEW IF EXISTS `complicatedvaccines`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `complicatedvaccines` AS select `person`.`UNLOCode` AS `UNLOCODE`,`person`.`latestVaccinatedDate` AS `latestVaccinatedDate`,`person`.`administedVaccineType` AS `administedVaccineType`,`person`.`vaccineComplications` AS `vaccineComplications` from `person` where (`person`.`vaccineComplications` = 'Yes') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-06 22:56:48
