CREATE DATABASE  IF NOT EXISTS `covid` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `covid`;
-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: covid
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `workingat`
--

DROP TABLE IF EXISTS `workingat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workingat` (
  `address` varchar(100) NOT NULL,
  `workerLicence` varchar(15) NOT NULL,
  PRIMARY KEY (`address`,`workerLicence`),
  KEY `workerLicence` (`workerLicence`),
  CONSTRAINT `workingat_ibfk_1` FOREIGN KEY (`address`) REFERENCES `healthcarecentre` (`address`),
  CONSTRAINT `workingat_ibfk_2` FOREIGN KEY (`workerLicence`) REFERENCES `healthcareworker` (`workerLicence`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workingat`
--

LOCK TABLES `workingat` WRITE;
/*!40000 ALTER TABLE `workingat` DISABLE KEYS */;
INSERT INTO `workingat` VALUES ('459 hume st, collingwood','107344720'),('58 anson dr, iroquois falls','141334099'),('325 margaret ave, wallaceburg','190076846'),('75 charles st, brockville','224755424'),('401 smyth road, ottawa','225238695'),('4650 hwy 7, woodbridge','228738913'),('205 mcnabb street, sault ste marie','228925290'),('200 terrace hill st, brantford','246098353'),('29 noxon st, ingersoll','246477274'),('250 college st, toronto','260482258'),('600 sanatorium rd, london','294709014'),('42 garden street, brockville','300932191'),('450 blanche street, petrolia','318379331'),('350 john st n, arnprior','355972333'),('1001 queen st w, toronto','410030860'),('9 huntley street, toronto','429349362'),('33 russell st, toronto','481598911'),('80 grand ave w, chatham','513423102'),('840 mcconnell ave, cornwall','579935155'),('120 dorothy st, atikokan','591046328'),('274 huron road, goderich','694101962'),('146 oliver rd, campbellford','750699054'),('120 napier street, goderich','828711257'),('507 8 ave, matheson','831993528'),('700 coronation blvd, cambridge','845636927'),('75 spring st, almonte','899423045'),('525 causley st, blind river','919221778'),('89 norman st, sarnia','969410649'),('175 brentcliffe rd, toronto','981833638'),('211 lake ave e, carleton place','994717970');
/*!40000 ALTER TABLE `workingat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-06 22:56:47
